#! /bin/sh

cd /ctf
./pwn2
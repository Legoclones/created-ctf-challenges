#! /bin/sh

cd /ctf
./pwn3
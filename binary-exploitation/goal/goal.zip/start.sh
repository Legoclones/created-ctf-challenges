#!/bin/bash

cd /ctf && ./goal
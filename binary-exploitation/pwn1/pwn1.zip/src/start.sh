#! /bin/sh

cd /ctf
./pwn1
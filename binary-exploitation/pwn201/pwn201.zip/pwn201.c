#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#define MAX_CHUNKS 10
#define CHUNK_SIZE 0x60

enum {
    FREE = 1,
    ALLOCATE,
    WRITE,
    READ,
    EXIT
} options;


__attribute__((constructor)) void flush_buf() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}


char * chunks[MAX_CHUNKS];


void print_menu() {
    printf("1. Free\n");
    printf("2. Allocate\n");
    printf("3. Write\n");
    printf("4. Read\n");
    printf("5. Exit\n");
    printf("> ");
}


int main(int argc, char* argv[]) {
    chunks[0] = malloc(CHUNK_SIZE);
    int chunk_count = 1;

    // read flag.txt into the first chunk
    int flag_fd = open("flag.txt", 0);
    if (flag_fd < 0) {
        printf("Could not open flag.txt\n");
        exit(1);
    }
    read(flag_fd, chunks[0]+0x10, CHUNK_SIZE-0x10);
    close(flag_fd);
    
    while (1) {
        print_menu();
        int choice;
        scanf("%d", &choice);

        // Free
        if (choice == FREE) {
            int idx;
            printf("Index: ");
            scanf("%d", &idx);
            if (idx < 1 || idx >= chunk_count) {
                printf("Invalid index\n");
            }
            else {
                free(chunks[idx]);
            }
        }

        // Allocate
        else if (choice == ALLOCATE) {
            if (chunk_count < MAX_CHUNKS) {
                chunks[chunk_count] = malloc(CHUNK_SIZE);
                chunk_count++;
            }
            else {
                printf("No more chunks available\n");
            }
        }

        // Write
        else if (choice == WRITE) {
            int idx;
            printf("Index: ");
            scanf("%d", &idx);
            if (idx < 1 || idx >= chunk_count) {
                printf("Invalid index\n");
            }
            else {
                printf("Data: ");
                scanf("%95s", chunks[idx]);
            }
        }

        // Read
        else if (choice == READ) {
            int idx;
            printf("Index: ");
            scanf("%d", &idx);
            if (idx < 1 || idx >= chunk_count) {
                printf("Invalid index\n");
            }
            else {
                write(1, chunks[idx], CHUNK_SIZE);
            }
        }

        // Exit
        else if (choice == EXIT) {
            break;
        }

        else {
            printf("Invalid choice\n");
        }
    }

    return 0;
}
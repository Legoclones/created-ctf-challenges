#!/bin/bash

cd /ctf && ./gorl